/**
 * REST helpers for the Retention & Cross-Sell Radar. Types live in
 * shared/types.ts. This file only contains `fetch` calls.
 */
import { okOrThrow } from './api';
import type {
  RadarRow,
  RadarDetail,
  RadarSummary,
  RadarStatus,
  RiskBand,
  BranchBucket,
  ActivityEvent,
} from '@/shared/types';

export type RadarFilters = {
  status?: RadarStatus;
  nbaType?: 'retention' | 'cross_sell';
  riskBand?: RiskBand;
  segment?: string;
  branch?: string;
  sort?: 'priority' | 'risk' | 'cross_sell';
};

export async function fetchRadar(filters: RadarFilters = {}): Promise<RadarRow[]> {
  const qs = new URLSearchParams();
  if (filters.status) qs.set('status', filters.status);
  if (filters.nbaType) qs.set('nbaType', filters.nbaType);
  if (filters.riskBand) qs.set('riskBand', filters.riskBand);
  if (filters.segment) qs.set('segment', filters.segment);
  if (filters.branch) qs.set('branch', filters.branch);
  if (filters.sort) qs.set('sort', filters.sort);
  const res = await okOrThrow(await fetch(`/api/radar?${qs}`), '/api/radar');
  return res.json();
}

export async function fetchRadarDetail(id: string): Promise<RadarDetail> {
  const res = await okOrThrow(await fetch(`/api/radar/${id}`), `/api/radar/${id}`);
  return res.json();
}

export async function fetchRadarSummary(): Promise<RadarSummary> {
  const res = await okOrThrow(await fetch('/api/radar/summary'), '/api/radar/summary');
  return res.json();
}

export async function fetchBranchBreakdown(
  opts: { status?: RadarStatus; nbaType?: 'retention' | 'cross_sell' } = {},
): Promise<BranchBucket[]> {
  const qs = new URLSearchParams();
  if (opts.status) qs.set('status', opts.status);
  if (opts.nbaType) qs.set('nbaType', opts.nbaType);
  const res = await okOrThrow(
    await fetch(`/api/radar/by-branch?${qs}`),
    '/api/radar/by-branch',
  );
  return res.json();
}

export async function dismissRadar(id: string, notes?: string): Promise<void> {
  await okOrThrow(
    await fetch(`/api/radar/${id}/dismiss`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ notes }),
    }),
    `/api/radar/${id}/dismiss`,
  );
}

export async function fetchActivity(limit = 20): Promise<ActivityEvent[]> {
  const res = await okOrThrow(
    await fetch(`/api/activity/recent?limit=${limit}`),
    '/api/activity/recent',
  );
  return res.json();
}
