CREATE SCHEMA IF NOT EXISTS "app";
--> statement-breakpoint
CREATE TABLE "app"."balance_weekly" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"customer_id" text NOT NULL,
	"week_start" date NOT NULL,
	"balance_usd" double precision,
	"runoff_pct" double precision,
	"payroll_active" boolean,
	"at_risk_flag" boolean
);
--> statement-breakpoint
CREATE TABLE "app"."conversations" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_email" text NOT NULL,
	"title" text NOT NULL,
	"kind" text DEFAULT 'default' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "app"."feedback" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"message_id" uuid NOT NULL,
	"user_email" text NOT NULL,
	"value" text NOT NULL,
	"rationale" text,
	"trace_id" text,
	"mlflow_assessment_id" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "app"."messages" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"conversation_id" uuid NOT NULL,
	"role" text NOT NULL,
	"content" text NOT NULL,
	"position" integer NOT NULL,
	"trace_id" text,
	"thinking" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"error" text,
	"canceled" boolean DEFAULT false NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "app"."radar" (
	"id" text PRIMARY KEY NOT NULL,
	"first_name" text NOT NULL,
	"last_name" text NOT NULL,
	"email" text,
	"segment" text,
	"home_branch" text,
	"branch_region" text,
	"rm_name" text,
	"tenure_months" integer,
	"relationship_value_usd" double precision,
	"products_held" integer,
	"products_list" text,
	"total_balance_usd" double precision,
	"risk_band" text,
	"attrition_risk_score" double precision,
	"balance_runoff_pct" double precision,
	"days_since_last_payroll" integer,
	"payroll_interrupted" boolean,
	"nba_type" text DEFAULT 'none' NOT NULL,
	"nba_product" text,
	"nba_reason" text,
	"cross_sell_opportunity_usd" integer,
	"priority" integer,
	"status" text DEFAULT 'pending' NOT NULL,
	"action_taken" text,
	"offer_summary" text,
	"emails" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"ai_audit_trail" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"decided_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "app"."transactions" (
	"id" text PRIMARY KEY NOT NULL,
	"customer_id" text NOT NULL,
	"txn_date" timestamp with time zone,
	"amount_usd" double precision,
	"txn_type" text,
	"channel" text
);
--> statement-breakpoint
ALTER TABLE "app"."feedback" ADD CONSTRAINT "feedback_message_id_messages_id_fk" FOREIGN KEY ("message_id") REFERENCES "app"."messages"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "app"."messages" ADD CONSTRAINT "messages_conversation_id_conversations_id_fk" FOREIGN KEY ("conversation_id") REFERENCES "app"."conversations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE UNIQUE INDEX "balance_weekly_cust_week_uq" ON "app"."balance_weekly" USING btree ("customer_id","week_start");--> statement-breakpoint
CREATE INDEX "balance_weekly_cust_idx" ON "app"."balance_weekly" USING btree ("customer_id","week_start");--> statement-breakpoint
CREATE INDEX "conversations_user_idx" ON "app"."conversations" USING btree ("user_email","updated_at");--> statement-breakpoint
CREATE INDEX "conversations_kind_idx" ON "app"."conversations" USING btree ("user_email","kind");--> statement-breakpoint
CREATE INDEX "feedback_message_idx" ON "app"."feedback" USING btree ("message_id");--> statement-breakpoint
CREATE UNIQUE INDEX "messages_convo_pos_uq" ON "app"."messages" USING btree ("conversation_id","position");--> statement-breakpoint
CREATE INDEX "radar_status_idx" ON "app"."radar" USING btree ("status","priority");--> statement-breakpoint
CREATE INDEX "radar_nba_idx" ON "app"."radar" USING btree ("nba_type");--> statement-breakpoint
CREATE INDEX "radar_branch_idx" ON "app"."radar" USING btree ("home_branch");--> statement-breakpoint
CREATE INDEX "radar_risk_idx" ON "app"."radar" USING btree ("risk_band");--> statement-breakpoint
CREATE INDEX "transactions_cust_idx" ON "app"."transactions" USING btree ("customer_id","txn_date");